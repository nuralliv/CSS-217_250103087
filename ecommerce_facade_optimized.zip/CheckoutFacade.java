package com.ecommerce;

/**
 * The Facade Class: CheckoutFacade
 * Coordinates the underlying subsystems (Inventory, Payment, Shipping, Notification)
 * behind a unified, single-method interface for callers.
 *
 * Optimization notes (per "Beyond Design Patterns" handout):
 *  - No interfaces were introduced: each subsystem has exactly one implementation,
 *    so call sites stay monomorphic and HotSpot can inline them (Checklist Q1/Q2).
 *  - The facade and its services are stateless and final: create ONE instance and
 *    reuse it. No per-call wrapper/adapter allocation (GC churn, Section 2C).
 *  - Cheap validation runs before any side effects (reserve/charge), so bad input
 *    never triggers needless work.
 *  - A failed payment now releases the reserved stock (previously leaked).
 */
public final class CheckoutFacade {

    // Subsystem instances maintained by the Facade (final -> safe publication, inlinable)
    private final InventoryService inventory;
    private final PaymentGateway payment;
    private final ShippingService shipping;
    private final NotificationService notification;

    /**
     * Step 1: Initialize all internal subsystem dependencies.
     * Kept as plain construction: with a single implementation per service,
     * injection/interfaces would be speculative abstraction (handout Section 6).
     */
    public CheckoutFacade() {
        this.inventory = new InventoryService();
        this.payment = new PaymentGateway();
        this.shipping = new ShippingService();
        this.notification = new NotificationService();
    }

    /**
     * Step 2: Unified checkout orchestrator.
     * Coordinates the full multi-service workflow in the proper sequence.
     *
     * @param productId Identifier of the purchased item.
     * @param customerId Identifier of the purchasing user.
     * @param address Physical delivery destination.
     * @param amount Total transaction charge.
     * @return true if the entire checkout workflow succeeded, false otherwise.
     */
    public boolean placeOrder(String productId, String customerId, String address, double amount) {
        System.out.println("=== [CheckoutFacade] Starting Order Placement Workflow ===");

        // Step 2.0: Fail fast on invalid input before touching any subsystem
        if (productId == null || customerId == null || address == null
                || !(amount > 0.0)) { // !(x > 0) also rejects NaN
            System.out.println("[CheckoutFacade] Aborting: Invalid order request.");
            return false;
        }

        // Step 2.1: Verify warehouse inventory availability
        if (!inventory.checkStock(productId)) {
            System.out.println("[CheckoutFacade] Aborting: Item out of stock.");
            return false;
        }

        // Step 2.2: Reserve the item in stock
        inventory.reserve(productId);

        // Step 2.3: Process billing and charge customer
        if (!payment.charge(customerId, amount)) {
            System.out.println("[CheckoutFacade] Aborting: Payment declined.");
            inventory.release(productId); // Step 2.3b: roll back reservation
            return false;
        }

        // Step 2.4: Schedule logistics carrier dispatch
        shipping.scheduleDelivery(productId, address);

        // Step 2.5: Dispatch digital receipt confirmation
        notification.sendReceipt(customerId, amount);

        System.out.println("=== [CheckoutFacade] Order Workflow Completed Successfully ===");
        return true;
    }
}
